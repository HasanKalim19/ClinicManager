const envLocal = {
  host: 'localhost',
  username: 'root',
  password: '',
  port: 3306,
  database: 'db_clinic',
};
const prodLocal = {
  host: 'localhost',
  username: 'root',
  password: '',
  port: 3306,
  database: 'db_clinic',
};
module.exports = {
  envLocal,
  prodLocal,
};
